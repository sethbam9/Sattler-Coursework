from django.apps import AppConfig


class JourneyConfig(AppConfig):
    name = 'journey'
